// Cartas y palos

const valoresCartas = ['A', '2', '3', '4', '5', '6', '7', '8', '9', '10', 'J', 'Q', 'K'];
const palosCartas = ['picas', 'corazones', 'diamantes', 'tréboles'];
// Variables
let nombreJugador = "Jugador";
let cartasBarajadas = [];
let manoBanca = [];
let manoJugador = [];
let partidaTerminada = true;

// REFERENCIAS DEL DOM (No se pueden traducir los IDs del HTML)
const divManoBanca = document.getElementById('dealer-hand');
const divManoJugador = document.getElementById('player-hand');
const spanPuntuacionBanca = document.getElementById('dealer-score');
const spanPuntuacionJugador = document.getElementById('player-score');
const spanNombreJugador = document.getElementById('player-name');
const cajaMensajes = document.getElementById('mensaje');
const btnPedirCarta = document.getElementById('btn-pedirCarta');
const btnPlantarse = document.getElementById('btn-plantarse');
const btnNuevaPartida = document.getElementById('btn-nuevaPartida');


// --- valor de las cartas ---

function obtenerPuntosCarta(valor) {
    if (['J', 'Q', 'K'].includes(valor)) {
        return 10;
    }
    if (valor === 'A') {
        return 1;
    }
    return parseInt(valor);
}

function calcularPuntuacion(mano) {
    let puntuacion = 0;
    mano.forEach(carta => {
        puntuacion += obtenerPuntosCarta(carta.valor);
    });
    return puntuacion;
}

function crearCartasBarajadas() {
    let nuevoCartasBarajadas = [];
    for (const valor of valoresCartas) {
        for (const palo of palosCartas) {
            nuevoCartasBarajadas.push({ valor, palo });
        }
    }
    // Algoritmo para barajar y redondear a la baja
    for (let i = nuevoCartasBarajadas.length - 1; i > 0; i--) {
        const j = Math.floor(Math.random() * (i + 1));
        [nuevoCartasBarajadas[i], nuevoCartasBarajadas[j]] = [nuevoCartasBarajadas[j], nuevoCartasBarajadas[i]];
    }
    return nuevoCartasBarajadas;
}

function sacarCarta() {
    if (cartasBarajadas.length === 0) {
        cartasBarajadas = crearCartasBarajadas();
    }
    return cartasBarajadas.pop();
}


// valor del palo

function obtenerSimboloPalo(palo) {
    switch (palo) {
        case 'corazones': return '♥';
        case 'diamantes': return '♦';
        case 'picas': return '♠';
        case 'tréboles': return '♣';
        default: return '';
    }
}


 // Crea el elemento HTML para una carta.

function crearElementoCarta(carta) {
    const divCarta = document.createElement('div');
    const simboloPalo = obtenerSimboloPalo(carta.palo);

    // Determina el color: text-danger (rojo) para corazones/diamantes, text-dark (negro) para otros.
    const claseColorBootstrap = (carta.palo === 'corazones' || carta.palo === 'diamantes') ? 'text-danger' : 'text-dark';
    
    divCarta.className = `card-blackjack card border-dark text-center ${claseColorBootstrap}`;
    
    divCarta.innerHTML = `
        <div class="align-self-start">${carta.valor}</div>
        <div class="fs-3">${simboloPalo}</div>
        <div class="align-self-end text-sm-end">${carta.valor}</div>
    `;
    return divCarta;
}


// Dibuja una mano de cartas y actualiza la puntuación y appendChild para que nos retorne

function renderizarMano(mano, divMano, spanPuntuacion) {
    divMano.innerHTML = '';
    mano.forEach(carta => {
        divMano.appendChild(crearElementoCarta(carta));
    });
    const puntuacion = calcularPuntuacion(mano);
    spanPuntuacion.textContent = puntuacion;
    return puntuacion;
}


// Muestra un mensaje de estado o resultado final (usando alerts de Bootstrap).
function mostrarMensaje(mensaje, tipo = 'info') {
    cajaMensajes.textContent = mensaje;
    
    cajaMensajes.classList.remove('d-none', 'alert-danger', 'alert-success', 'alert-info', 'alert-warning');
    
    let claseAlerta = 'alert-info'; 

    if (tipo === 'gana') {
        claseAlerta = 'alert-success'; 
    } else if (tipo === 'pierde') {
        claseAlerta = 'alert-danger'; 
    } else if (tipo === 'empate') {
        claseAlerta = 'alert-warning'; 
    }

    cajaMensajes.classList.add('alert', claseAlerta);
}

function establecerControlesHabilitados(habilitar) {
    btnPedirCarta.disabled = !habilitar;
    btnPlantarse.disabled = !habilitar;
}


// Juego

function iniciarJuego() {
    // Pedimos el nombre del jugador
    const entradaNombre = prompt("Por favor, introduce tu nombre de jugador:", "Jugador");
    if (entradaNombre) {
        nombreJugador = entradaNombre.trim() || "Jugador";
    }
    spanNombreJugador.textContent = nombreJugador;
    
    // Resetear estado
    partidaTerminada = false;
    cartasBarajadas = crearCartasBarajadas();
    manoBanca = [];
    manoJugador = [];
    divManoBanca.innerHTML = '';
    divManoJugador.innerHTML = '';
    spanPuntuacionBanca.textContent = '0';
    spanPuntuacionJugador.textContent = '0';
    cajaMensajes.classList.add('d-none');
    establecerControlesHabilitados(false);
    
    // Reparte cartas iniciales
    repartirCarta('jugador'); 
    repartirCarta('banca');
    repartirCarta('jugador');
    repartirCarta('banca'); 
    
    // Iniciar turno de la banca
    setTimeout(turnoBanca, 1000); 
}

function repartirCarta(destino) {
    if (partidaTerminada) return;
    const nuevaCarta = sacarCarta();
    
    if (destino === 'jugador') {
        manoJugador.push(nuevaCarta);
        const puntuacion = renderizarMano(manoJugador, divManoJugador, spanPuntuacionJugador);
        
        if (puntuacion > 21) {
            mostrarMensaje(`${nombreJugador} se pasó con ${puntuacion} puntos. ¡La Banca gana!`, 'lose');
            finalizarJuego();
        } else if (puntuacion === 21) {
             mostrarMensaje(`${nombreJugador} tiene 21. La Banca jugará su turno.`, 'info');
             establecerControlesHabilitados(false);
             setTimeout(finalizarJuego, 1500);
        }
    } else if (destino === 'banca') {
        manoBanca.push(nuevaCarta);
        renderizarMano(manoBanca, divManoBanca, spanPuntuacionBanca);
    }
}

function turnoBanca() {
    if (partidaTerminada) return;
    mostrarMensaje("Turno de la Banca...", 'info');

    const jugarBanca = () => {
        const puntuacion = calcularPuntuacion(manoBanca);
        
        // La banca pide cartas hasta tener un mínimo de 17.
        if (puntuacion < 17) { 
            setTimeout(() => {
                repartirCarta('banca');
                const nuevaPuntuacion = calcularPuntuacion(manoBanca);
                
                if (nuevaPuntuacion > 21) {
                    mostrarMensaje(`La Banca se pasó con ${nuevaPuntuacion} puntos. ¡${nombreJugador} gana!`, 'win');
                    finalizarJuego();
                } else {
                    jugarBanca(); 
                }
            }, 1000);
        } else {
            if (!partidaTerminada) {
                mostrarMensaje(`La Banca se planta con ${puntuacion} puntos. Es tu turno, ${nombreJugador}.`, 'info');
                establecerControlesHabilitados(true);
            }
        }
    };

    if (!partidaTerminada) {
        jugarBanca();
    }
}

function jugadorSePlanta() {
    if (partidaTerminada) return;
    establecerControlesHabilitados(false);
    turnoBanca(); 
    setTimeout(finalizarJuego, 2000); 
}


function finalizarJuego() {
    if (partidaTerminada) return;
    partidaTerminada = true;
    establecerControlesHabilitados(false);

    const puntuacionJugador = calcularPuntuacion(manoJugador);
    const puntuacionBanca = calcularPuntuacion(manoBanca);

    let mensajeResultado = "";
    let tipoMensaje = 'info';

    if (puntuacionJugador > 21) {
        mensajeResultado = `${nombreJugador} (${puntuacionJugador}) se pasó. ¡La Banca gana!`;
        tipoMensaje = 'pierde';
    } else if (puntuacionBanca > 21) {
        mensajeResultado = `La Banca (${puntuacionBanca}) se pasó. ¡${nombreJugador} gana!`;
        tipoMensaje = 'gana';
    } 
    else if (puntuacionJugador > puntuacionBanca) {
        mensajeResultado = `¡${nombreJugador} gana! Tienes ${puntuacionJugador} vs Banca ${puntuacionBanca}.`;
        tipoMensaje = 'gana';
    } else if (puntuacionBanca > puntuacionJugador) {
        mensajeResultado = `¡La Banca gana! Tiene ${puntuacionBanca} vs ${puntuacionJugador}.`;
        tipoMensaje = 'pierde';
    } else {
        mensajeResultado = `¡Empate! Ambos tienen ${puntuacionJugador} puntos.`;
        tipoMensaje = 'empate';
    }

    mostrarMensaje(mensajeResultado, tipoMensaje);
}


// EVENT LISTENERS

btnPedirCarta.addEventListener('click', () => {
    if (partidaTerminada) return;
    mostrarMensaje(`${nombreJugador} pide carta...`, 'info');
    repartirCarta('jugador');
});

btnPlantarse.addEventListener('click', () => {
    if (partidaTerminada) return;
    mostrarMensaje(`${nombreJugador} se planta. Turno de la Banca...`, 'info');
    jugadorSePlanta();
});

btnNuevaPartida.addEventListener('click', iniciarJuego);

// Se inicia el juego al cargar la página
document.addEventListener('DOMContentLoaded', iniciarJuego);